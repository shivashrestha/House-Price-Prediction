----DSP assignment, EPITA----
Modules for house prices prediction.
1. preprocess.py
2. train.py
3. inference.py

____import as__________
from house_prices_shiva import train, inference, preprocess